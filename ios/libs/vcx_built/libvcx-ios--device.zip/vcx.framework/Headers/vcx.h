//
//  vcx.h
//  vcx
//
//  Created by GuestUser on 4/30/18.
//  Copyright © 2018 GuestUser. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for vcx.
FOUNDATION_EXPORT double vcxVersionNumber;

//! Project version string for vcx.
FOUNDATION_EXPORT const unsigned char vcxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <vcx/PublicHeader.h>

#import "VcxAPI.h"
#import "VcxLogger.h"
#import "IndySdk.h"
#import "libvcx.h"

