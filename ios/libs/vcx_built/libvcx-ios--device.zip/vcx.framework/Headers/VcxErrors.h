//
//  VcxErrors.h
//  vcx-demo
//
//  Created by Norman Jarvis on 5/7/18.
//  Copyright © 2018 GuestUser. All rights reserved.
//

#ifndef VcxErrors_h
#define VcxErrors_h

typedef NS_ENUM(NSInteger, VcxErrorCode)
{
    Success = 0
};

#endif /* VcxErrors_h */
