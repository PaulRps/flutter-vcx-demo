//
//  IndyTypes.h
//  vcx
//
//  Created by Norman Jarvis on 2/18/19.
//  Copyright © 2019 GuestUser. All rights reserved.
//

#ifndef IndyTypes_h
#define IndyTypes_h

//typedef unsigned int indy_error_t;
//typedef unsigned int indy_handle_t;
typedef SInt32 IndyHandle;


#endif /* IndyTypes_h */